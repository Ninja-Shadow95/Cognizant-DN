package com.proxypattern.example;

public interface Image {
    void display();
}
