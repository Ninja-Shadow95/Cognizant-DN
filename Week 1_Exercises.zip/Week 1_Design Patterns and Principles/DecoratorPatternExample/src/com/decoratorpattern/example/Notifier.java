package com.decoratorpattern.example;

public interface Notifier {
    void send(String message);
}
