package com.factorymethod.example;

public abstract class DocumentFactory {
    public abstract Document createDocument();
}
