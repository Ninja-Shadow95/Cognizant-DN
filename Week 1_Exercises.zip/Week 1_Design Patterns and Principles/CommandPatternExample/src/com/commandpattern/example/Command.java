package com.commandpattern.example;

public interface Command {
    void execute();
}
