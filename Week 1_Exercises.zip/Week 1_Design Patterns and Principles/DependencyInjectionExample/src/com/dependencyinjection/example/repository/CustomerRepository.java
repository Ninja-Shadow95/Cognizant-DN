package com.dependencyinjection.example.repository;

public interface CustomerRepository {
    String findCustomerById(String customerId);
}
