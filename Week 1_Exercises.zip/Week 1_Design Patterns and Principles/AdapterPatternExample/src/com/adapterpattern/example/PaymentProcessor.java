package com.adapterpattern.example;

public interface PaymentProcessor {
    void processPayment(double amount);
}
