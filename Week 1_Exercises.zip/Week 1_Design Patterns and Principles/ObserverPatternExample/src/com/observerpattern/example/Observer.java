package com.observerpattern.example;

public interface Observer {
    void update(double stockPrice);
}
